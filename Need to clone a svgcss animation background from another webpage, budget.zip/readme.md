source: https://ametrine.qodeinteractive.com/design-studio/

# Visit to see the page: https://nikhilroy2.github.io/Need-to-clone-a-svgcss-animation-background-from-another-webpage-budget/